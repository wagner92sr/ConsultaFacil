$(function() {
  $('.datepicker').datepicker();
});

$('.datetimepicker').datetimepicker();
